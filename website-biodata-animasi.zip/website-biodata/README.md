# Website Biodata Mahasiswa – Ahmad Ferdian

Biodata multi-halaman bergaya menu jeda *Persona 3 Reload* (HTML + CSS + JavaScript murni).

## Halaman
| File | Isi |
|---|---|
| `index.html` | Beranda: menu roda (Profil, Proyek, Keahlian, Kesan, Kontak) |
| `profil.html` · `proyek.html` · `keahlian.html` · `kesan.html` · `kontak.html` | Satu halaman per menu |

Saat website dibuka, muncul layar awal: klik atau tekan tombol apa saja untuk masuk (sekali per sesi tab). Ini juga yang mengizinkan browser memutar suara dan musik.

Memilih menu membuka file HTML-nya dengan transisi bergaya percikan air P3R: menu yang dipilih menghentak, lingkaran putih-cyan-navy membesar dari menu itu, lalu halaman tujuan terbuka dengan sabetan putih-merah, tab L/R jatuh masuk, dan isi halaman masuk satu per satu. Antarhalaman (L/R) memakai sapuan slab. Tombol **L / R** pindah antarhalaman, **B / Esc** kembali ke menu.

## Mengisi Kesan & Pesan
Buka `kesan.html`. Ada 4 kotak: 2 untuk **Kesan** dan 2 untuk **Pesan**. Di tiap kotak, ganti judul (`<h4>`) dan teks (`<p>`), lihat komentar `KELOMPOK KESAN` / `KELOMPOK PESAN`.

## Berkas lain
- `script.js` – menu, transisi lintas halaman, suara, galeri
- `air.js` – partikel air (gelembung, confetti, kilau, riak). Kursor mendorong gelembung, klik memunculkan riak
- `musik.js` + `playlist.js` – musik latar (lanjut dari posisi yang sama saat pindah halaman). Setiap lagu berganti, kotak judul lagu geser dari kiri ke kanan
- `galeri.js` – daftar gambar galeri (folder `galeri/`, galeri1–galeri5)
- Folder `foto/` (foto1–5), `galeri/` (galeri1–5), dan `musik/` (mp3) diisi sendiri. Ekstensi gambar bebas: .jpg, .jpeg, .png, .webp

## Foto profil (kartu arcana)
Di halaman Profil, foto tampil sebagai tumpukan kartu arcana. Taruh `foto1.jpg`, `foto2.jpg`, `foto3.jpg`, dst. di folder `foto/` (otomatis terdeteksi sampai foto12, ekstensi bebas).
Foto **berganti sendiri** sesuai urutan (foto1 → foto2 → ... → kembali ke foto1) tanpa perlu diklik; batang kecil di bawah kartu menunjukkan waktu menuju foto berikutnya. Atur kecepatan lewat `AUTO` (milidetik, default 3800) di `script.js`. Berhenti sementara saat tab disembunyikan atau saat pindah halaman. Klik/ketuk tetap bisa dipakai untuk melompat ke foto berikutnya, geser ke kanan = sebelumnya.
Saran untuk HP: kecilkan foto ke lebar sekitar 1000 px (200-400 KB per foto) supaya cepat dimuat.

## Animasi 60 fps
Transisi memakai transform/opacity (jalur GPU), termasuk lingkaran "iris" yang di-scale. `air.js` menargetkan 60 fps (layar 120/144 Hz tetap dibatasi 60), memakai mode ringan di HP / perangkat lemah (partikel lebih sedikit, resolusi kanvas dibatasi), dan menurunkan jumlah partikel sendiri bila rata-rata frame > 22 ms. CSS juga mematikan efek berat (blend, blur, animasi latar) di layar sentuh. Tombol "Animasi" tetap bisa mematikan semuanya.

## Menjalankan
Buka `index.html` langsung, atau lewat server lokal (misal `python -m http.server`).
